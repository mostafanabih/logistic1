

<?php $__env->startSection('content'); ?>
    <header class="pages-header bg-img valign parallaxie" data-background="https://www.swaralaqar.com/images//projects/202102213473122718.jpg" data-overlay-dark="5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cont text-center">
                        <h1><?php echo e($info->name); ?></h1>
                        <div class="path">
                            <a href="<?php echo e(route('index')); ?>">الرئيسية</a><span>/</span><a href="#0" class="active"> <?php echo e($info->name); ?> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section class="mextreo-hero inner mar-bot-50">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="hero-content">
                        <h6 class="ht-tittle aos-init aos-animate" data-aos="fade-right" data-aos-duration="1500">حول المشروع</h6>
                        <h2 data-aos="fade-up" data-aos-duration="2000" class="aos-init aos-animate"> <?php echo e($info->name); ?></h2>
                        <p data-aos="fade-up" data-aos-duration="2500" class="aos-init aos-animate"> <p><?php echo e($info->description); ?><br>&nbsp;</p>.
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="project slider slider-prlx">
                        <div class="swiper-container parallax-slider">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $info->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="swiper-slide">
                                    <div class="bg-img valign portfolio-img aos-animate " data-aos-duration="1500"> <a data-fancybox="gallery" href="../images/projects/2021021613656368981.jpg">
                                            <img src="<?php echo e(asset("storage/$image")); ?>" alt=""></a>
                                    </div>
                                </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </div>
                            <div class="setone setwo">
                                <div class="swiper-button-next swiper-nav-ctrl next-ctrl cursor-pointer">
                                    <i class="fas fa-chevron-right"></i>
                                </div>
                                <div class="swiper-button-prev swiper-nav-ctrl prev-ctrl cursor-pointer">
                                    <i class="fas fa-chevron-left"></i>
                                </div>
                            </div>
                            <div class="swiper-pagination top botm custom-font"></div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sohb\resources\views/frontend/show_project.blade.php ENDPATH**/ ?>