

<?php $__env->startSection('content'); ?>
    <header class="pages-header bg-img valign parallaxie" data-background="<?php echo e(asset('assets/projects/projects.jpg')); ?>" data-overlay-dark="5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cont text-center">
                        <h1>   مشاريعنا</h1>
                        <div class="path">
                            <a href="<?php echo e(route('index')); ?>">الرئيسية</a><span>/</span><a href="#0" class="active">    مشاريعنا </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section class="project-gallery section-padding">
        <div class="container">
            <div class="services-title custom-font tr-head">
                <h6 class="ht-tittle aos-init aos-animate" data-aos="fade-right" data-aos-duration="1500">أحدث المشاريع</h6>
                <h3 data-aos="fade-up" data-aos-duration="2000" class="aos-init aos-animate"> مشاريعنا</h3>
            </div>

            <div class="row mt-30">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="portfolio-img aos-init aos-animate" data-aos="fade-up" data-aos-duration="1500" style="    width: 350px;height: 348px;"> <a data-fancybox="gallery" href="images/thumbnail/projects/202102161375162054.jpg">
                    <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img  src="<?php if($loop->first): ?> <?php echo e(asset("storage/$image")); ?> <?php endif; ?>"  alt="" style="height:350px;width:329px;"><i class="flaticon-add rp-icon"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="sp-text">
                            <h3><?php echo e($project->name); ?></h3>
                            <p><p><?php echo e($project->description); ?></p>
                            <div class="stage">
                                <a href="<?php echo e(route('show_project',$project->id)); ?>"><i class="fas fa-chevron-left"></i>اقراء المزيد</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                    <div class="col-lg-12 col-md-12">
                        <ul class="pagination">
                            
                        </ul>
                    </div>
            </div>

        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sohb\resources\views/frontend/projects.blade.php ENDPATH**/ ?>