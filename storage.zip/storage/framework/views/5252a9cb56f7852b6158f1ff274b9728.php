<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('filament-language-switch', []);

$__html = app('livewire')->mount($__name, $__params, 'fls-in-panels', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH E:\xampp\htdocs\sohb\storage\framework\views/f07f1a332c895be3dafc362336ba959c.blade.php ENDPATH**/ ?>