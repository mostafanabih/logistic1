<script src="<?php echo e(asset('assets/js/jquery-3.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-migrate-3.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
<script>
    AOS.init();
</script><?php /**PATH E:\xampp\htdocs\sohb\resources\views/frontend/site/partials/scripts.blade.php ENDPATH**/ ?>